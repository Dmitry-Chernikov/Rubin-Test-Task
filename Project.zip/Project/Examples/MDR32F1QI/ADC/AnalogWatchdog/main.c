/**
 ******************************************************************************
 * @file    main.c
 * @author  Milandr Application Team
 * @version V2.1.0
 * @date    22/06/2023
 * @brief   Основное тело программы.
 ******************************************************************************
 * <br><br>
 *
 * НАСТОЯЩАЯ ПРОШИВКА ПРЕДОСТАВЛЕНА ТОЛЬКО ДЛЯ Справки. ЕЁ ЦЕЛЬ – ПРЕДОСТАВИТЬ
 * КЛИЕНТАМ ИНФОРМАЦИЮ О РАЗРАБОТКЕ КОДА ДЛЯ ПРОДУКЦИИ MILANDR, ЧТОБЫ
 * ОБЕСПЕЧИТЬ ПРОСТОЕ ИСПОЛЬЗОВАНИЕ И СЭКОНОМИТЬ ВРЕМЯ. MILANDR НЕ НЕСЁТ ОТВЕТСТВЕННОСТИ
 * ЗА ЛЮБЫЕ ПРЯМЫЕ, КОСВЕННЫЕ ИЛИ ПОСЛЕДУЮЩИЕ УБЫТКИ, ВОЗНИКАЮЩИЕ В РЕЗУЛЬТАТЕ
 * СОДЕРЖАНИЯ ДАННОЙ ПРОШИВКИ И/ИЛИ ИСПОЛЬЗОВАНИЯ ЕЁ КЛИЕНТАМИ.
 *
 * <h2><center>&copy; COPYRIGHT 2024 Milandr </center></h2>
 */

/* Подключение необходимых заголовочных файлов ---------------------------------*/
#include "stdio.h"
#include "MDR32FxQI_config.h"
#include "MDR32FxQI_port.h"
#include "MDR32FxQI_rst_clk.h"
#include "MDR32FxQI_utils.h"
#include "MDR32FxQI_adc.h"

/** @addtogroup __MDR32FxQI_StdPeriph_Examples Примеры стандартной периферии MDR32FxQI
 * @{
 */
/** @addtogroup __MDR32F1QI_EVAL Плата оценки MDR32F1QI
 * @{
 */
/** @addtogroup ADC_AnalogWatchdog_MDR32F1QI ADC_AnalogWatchdog
 * @{
 */

/* Приватное определение типа --------------------------------------------------*/
#if defined(_USE_DEBUG_UART_)
#define DEBUG_PRINTF(...) printf(__VA_ARGS__)
#else
#define DEBUG_PRINTF(...)
#endif /* #if defined _USE_DEBUG_UART_ */

/* Приватные переменные ---------------------------------------------------------*/
__IO uint32_t H_Level = 0x900; // Высокий порог
__IO uint32_t L_Level = 0x800; // Низкий порог
int result;
PORT_InitTypeDef PORT_InitStructure;
ADC_InitTypeDef sADC;
ADCx_InitTypeDef ADCx;

/* Прототипы приватных функций -----------------------------------------------*/
#if defined(_USE_DEBUG_UART_)
void ClockConfigure(void);
#endif

/* Приватные функции ---------------------------------------------------------*/
/**
 * @brief  Обработчик прерывания АЦП.
 * @param  Нет
 * @retval Нет
 */
void ADC_IRQHandler(void)
{ 
    /*Флаг выставляется, когда результат преобразования выше верхней 
    или ниже нижней границы автоматического контролирования уровней.*/
    if (ADC1_GetFlagStatus(ADCx_FLAG_OUT_OF_RANGE) == SET)
    {
        /* Включение светодиода LED1 */
        PORT_SetBits(MDR_PORTD, PORT_Pin_10);
    }
    else    
    {
        /* Выключение светодиода LED1 */
        PORT_ResetBits(MDR_PORTD, PORT_Pin_10);
    }

    result = ADC1_GetResult() & ADC_RESULT_Msk;

    if (result > H_Level)
    {
        /* Включение светодиода LED2 */
        PORT_SetBits(MDR_PORTD, PORT_Pin_11);
    }
    else
    {
        /* Выключение светодиода LED2 */
        PORT_ResetBits(MDR_PORTD, PORT_Pin_11);
    }
    
    /* Сброс флага прерывания АЦП по условию OUT_OF_RANGE */
    ADC1_ClearOutOfRangeFlag();
}

/**
 * @brief  Основная программа.
 * @param  Нет
 * @retval Нет
 */
int main(void)
{
#if defined(_USE_DEBUG_UART_)
    ErrorStatus Status;
#endif

    RST_CLK_DeInit(); //Установите конфигурацию часов RST_CLK в состояние сброса по умолчанию. 

#if defined(_USE_DEBUG_UART_)
    ClockConfigure();
#endif /* #if defined (_USE_DEBUG_UART_) */

    SystemCoreClockUpdate(); // Обновление SystemCoreClock в соответствии со значениями регистрации часов 

#if defined(_USE_DEBUG_UART_)
    Status = STDIO_Init();
    if (Status == ERROR)
    {
        while (1)
        {
        }
    }
#endif /* #if defined (_USE_DEBUG_UART_) */

    /* Включение тактирования периферийных устройств */
    RST_CLK_PCLKcmd((RST_CLK_PCLK_RST_CLK | RST_CLK_PCLK_ADC | RST_CLK_PCLK_PORTD), ENABLE);

    /* Сброс настроек порта PORTD */
    PORT_DeInit(MDR_PORTD);

    /* Настройка контакта АЦП: ADC2 */
    /* Настройка контакта 9 порта PORTD */
    PORT_StructInit(&PORT_InitStructure);
    PORT_InitStructure.PORT_Pin = PORT_Pin_9;
    PORT_InitStructure.PORT_OE = PORT_OE_IN;
    PORT_InitStructure.PORT_MODE = PORT_MODE_ANALOG;
    PORT_Init(MDR_PORTD, &PORT_InitStructure);

    /* Настройка контактов 10 и 11 порта PORTD для управления светодиодами LED1 и LED2 */
    PORT_InitStructure.PORT_Pin = (PORT_Pin_10 | PORT_Pin_11);
    PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
    PORT_InitStructure.PORT_OE = PORT_OE_OUT;
    PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
    PORT_InitStructure.PORT_SPEED = PORT_SPEED_MAXFAST;
    PORT_Init(MDR_PORTD, &PORT_InitStructure);

    /* Конфигурация АЦП */
    /* Сброс всех настроек АЦП */
    ADC_DeInit();
    DEBUG_PRINTF("Инициализация АЦП...");

    // Инициализация тактирования для АЦП
    RST_CLK_ADCclkSelection(RST_CLK_ADCclkCPU_C1); // Выберите источник часов АЦП. 
    RST_CLK_ADCclkPrescaler(RST_CLK_ADCclkDIV2); // Конфигурирует переключатель коэффициента деления ADC_C3_SEL. 

    // Включение тактирования для АЦП
    RST_CLK_ADCclkEnable(ENABLE);

    ADC_StructInit(&sADC);
    sADC.ADC_TempSensor = ADC_TEMP_SENSOR_Enable;
    sADC.ADC_TempSensorAmplifier = ADC_TEMP_SENSOR_AMPLIFIER_Enable;
    sADC.ADC_TempSensorConversion = ADC_TEMP_SENSOR_CONVERSION_Disable;
    sADC.ADC_IntVRefConversion = ADC_VREF_CONVERSION_Disable;
    sADC.ADC_IntVRefTrimming = 0;
    sADC.ADC_IntVRefAmplifier = ADC_INT_VREF_AMPLIFIER_Enable;
    ADC_Init(&sADC);

    ADCx_StructInit(&ADCx);
    ADCx.ADC_ClockSource = ADC_CLOCK_SOURCE_CPU;
    ADCx.ADC_SamplingMode = ADC_SAMPLING_MODE_CYCLIC_CONV;
    ADCx.ADC_ChannelSwitching = ADC_CH_SWITCHING_Disable;
    ADCx.ADC_ChannelNumber = ADC_CH_ADC2;
    ADCx.ADC_Channels = 0;
    ADCx.ADC_LevelControl = ADC_LEVEL_CONTROL_Enable;
    ADCx.ADC_LowLevel = L_Level;
    ADCx.ADC_HighLevel = H_Level;
    ADCx.ADC_VRefSource = ADC_VREF_SOURCE_INTERNAL;
    ADCx.ADC_IntVRefSource = ADC_INT_VREF_SOURCE_INEXACT;
    ADCx.ADC_Prescaler = ADC_CLK_div_16;
    ADCx.ADC_DelayGo = 0xF;
    ADC1_Init(&ADCx);

    /* Включение прерываний ADC1: завершение преобразования и выход за пределы диапазона */
    ADC1_ITConfig((ADCx_IT_END_OF_CONVERSION | ADCx_IT_OUT_OF_RANGE), ENABLE);

    /* Разрешение прерывания АЦП в контроллере NVIC */
    NVIC_EnableIRQ(ADC_IRQn);

    /* Включение ADC1 */
    ADC1_Cmd(ENABLE);

    while (1)
    {
    }
}

int findMax(const int arr[15]) {
    int max = arr[0];  // Предполагаем, что первый элемент – максимальный
    for (int i = 1; i < 15; i++) {
        if (arr[i] > max) {
            max = arr[i];  // Обновляем максимум, если найден элемент больше текущего максимума
        }
    }
    return max;
}

#if defined(_USE_DEBUG_UART_)
/**
 * @brief  Настройка тактовой частоты процессора.
 * @param  Нет
 * @retval Нет
 */
void ClockConfigure(void)
{
    /* Включение внешнего тактового генератора HSE */
    RST_CLK_HSEconfig(RST_CLK_HSE_ON);
    /* Ожидание готовности HSE */
    while (RST_CLK_HSEstatus() == ERROR)
    {
    }
    /* Выбор HSE в качестве источника для CPU_C1 */
    RST_CLK_CPUclkSelectionC1(RST_CLK_CPU_C1srcHSEdiv1);
    /* Выбор CPU_C1 в качестве источника для CPU_C2 */
    RST_CLK_CPU_PLLuse(DISABLE);
    /* Выбор CPU_C2 в качестве источника для CPU_C3 */
    RST_CLK_CPUclkSelection(RST_CLK_CPUclkCPU_C3);
}
#endif /* #if defined (_USE_DEBUG_UART_) */

/**
 * @brief  Выводит имя исходного файла, номер строки и (если USE_ASSERT_INFO == 2)
 *         текст выражения, в котором произошла ошибка assert_param.
 * @param  file: указатель на имя исходного файла
 * @param  line: номер строки, где произошла ошибка assert_param
 * @param  expr: (если используется) текст выражения
 * @retval Нет
 */
#if (USE_ASSERT_INFO == 1)
void assert_failed(uint8_t *file, uint32_t line)
{
    /* Пользователь может добавить свою реализацию для вывода имени файла и номера строки.
       Пример: printf("Неверное значение параметра: файл %s, строка %d\r\n", file, line) */
    /* Бесконечный цикл */
    while (1)
    {
    }
}
#elif (USE_ASSERT_INFO == 2)
void assert_failed(uint8_t *file, uint32_t line, const uint8_t *expr)
{
    /* Пользователь может добавить свою реализацию для вывода имени файла, номера строки и
       текста выражения.
       Пример: printf("Неверное значение параметра (%s): файл %s, строка %d\r\n", expr, file, line) */
    /* Бесконечный цикл */
    while (1)
    {
    }
}
#endif /* USE_ASSERT_INFO */

/** @} */ /* Конец группы ADC_AnalogWatchdog_MDR32F1QI */
/** @} */ /* Конец группы __MDR32F1QI_EVAL */
/** @} */ /* Конец группы __MDR32FxQI_StdPeriph_Examples */
          /******************* (C) COPYRIGHT 2024 Milandr *******************************
             Конец файла main.c */