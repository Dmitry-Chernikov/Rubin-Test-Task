/**
 ******************************************************************************
 * @file    main.c
 * @author  Milandr Application Team
 * @version V2.1.0
 * @date    22/06/2023
 * @brief   Основное тело программы.
 ******************************************************************************
 * <br><br>
 *
 * ДАННАЯ ФАМИЛЬНАЯ ПРОШИВКА ПРЕДОСТАВЛЯЕТСЯ ТОЛЬКО ДЛЯ Справки. ЕЁ ЦЕЛЬ –
 * ПРЕДОСТАВИТЬ КЛИЕНТАМ ИНФОРМАЦИЮ О РАЗРАБОТКЕ КОДА ДЛЯ ПРОДУКЦИИ MILANDR,
 * ЧТОБЫ ОБЕСПЕЧИТЬ ПРОСТОЕ ИСПОЛЬЗОВАНИЕ И ЭКОНОМИЮ Времени. MILANDR НЕ
 * НЕСЁТ ОТВЕТСТВЕННОСТИ ЗА ЛЮБЫЕ ПРЯМЫЕ, КОСВЕННЫЕ ИЛИ ПОСЛЕДУЮЩИЕ УБЫТКИ,
 * ВОЗНИКАЮЩИЕ ИЗ СОДЕРЖАНИЯ ДАННОЙ ПРОШИВКИ И/ИЛИ ИЗ-ЗА ЕЁ ИСПОЛЬЗОВАНИЯ
 * КЛИЕНТАМИ ВИМКИХ ПРОДУКТОВ.
 *
 * <h2><center>&copy; COPYRIGHT 2024 Milandr </center></h2>
 */
/* Подключение необходимых заголовочных файлов --------------------------------*/
#include "stdio.h"
#include "MDR32FxQI_port.h"
#include "MDR32FxQI_eeprom.h"
#include "MDR32FxQI_rst_clk.h"
#include "MDR32FxQI_adc.h"
#include "MDR32FxQI_utils.h"
/** @addtogroup __MDR32FxQI_StdPeriph_Examples Примеры стандартной периферии MDR32FxQI
 *  @{
 */
/** @addtogroup __MDR32F1QI_EVAL Плата оценки MDR32F1QI
 *  @{
 */
/** @addtogroup ADC_ADC1_IT_MDR32F1QI ADC_ADC1_IT
 *  @{
 */
/* Приватные определения ------------------------------------------------------*/
#if defined(_USE_DEBUG_UART_)
#define DEBUG_PRINTF(...) printf(__VA_ARGS__)
#else
#define DEBUG_PRINTF(...)
#endif /* #if defined _USE_DEBUG_UART_ */
#define NUM_ADC_SAMPLING 16

/* Приватные переменные -------------------------------------------------------*/
PORT_InitTypeDef PORT_InitStructure;
ADC_InitTypeDef sADC;
ADCx_InitTypeDef ADCx;
uint16_t ADCConvertedValue[NUM_ADC_SAMPLING];
uint32_t Counter = 0;

/* Прототипы приватных функций ----------------------------------------------*/
#if defined(_USE_DEBUG_UART_)
void ClockConfigure(void);
#endif /* #if defined _USE_DEBUG_UART_ */

/* Приватные функции ---------------------------------------------------------*/
/**
 * @brief  Обработчик прерывания АЦП.
 * @param  Нет
 * @retval Нет
 */
void ADC_IRQHandler(void)
{
    if (ADC_GetITStatus(ADC1_IT_END_OF_CONVERSION) == SET)
    {
        ADCConvertedValue[Counter] = ADC1_GetResult();
        Counter = (Counter + 1) & (NUM_ADC_SAMPLING - 1);
        if (Counter == 0)
        {
            ADC1_Cmd(DISABLE);
            DEBUG_PRINTF("Преобразование АЦП завершено\r\n");
            while (Counter < NUM_ADC_SAMPLING)
            {
                DEBUG_PRINTF("ADC_Value[%d] = 0x%4x\r\n", Counter, ADCConvertedValue[Counter] & 0x0FFF);
                Counter++;
            }
        }
    }
}

/**
 * @brief  Основная программа.
 * @param  Нет
 * @retval Нет
 */
int main(void)
{
#if defined(_USE_DEBUG_UART_)
    ErrorStatus Status;
#endif

    RST_CLK_DeInit();

#if defined(_USE_DEBUG_UART_)
    ClockConfigure();
#endif /* #if defined (_USE_DEBUG_UART_) */

    SystemCoreClockUpdate();
    
#if defined(_USE_DEBUG_UART_)
    Status = STDIO_Init();
    if (Status == ERROR)
    {
        while (1)
        {
        }
    }
#endif /* #if defined (_USE_DEBUG_UART_) */

    /* Конфигурация АЦП */
    /* Сброс всех настроек АЦП */
    ADC_DeInit();
    DEBUG_PRINTF("Инициализация АЦП...");

    // Инициализация тактирования для АЦП
    RST_CLK_ADCclkSelection(RST_CLK_ADCclkCPU_C1); // Выберите источник часов АЦП. 
    RST_CLK_ADCclkPrescaler(RST_CLK_ADCclkDIV2); // Конфигурирует переключатель коэффициента деления ADC_C3_SEL. 

    // Включение тактирования АЦП
    RST_CLK_ADCclkEnable(ENABLE); // Включает или отключает часы ADC_CLK. 
    // RST_CLK_PCLK_ADC регистр PER_CLOCK Биты разрешения тактирования периферийных блоков
    RST_CLK_PCLKcmd(RST_CLK_PCLK_ADC, ENABLE); // Включает или отключает тактирования периферийных устройств. 
    ADC_StructInit(&sADC); // Заполняет каждый член ADC_INITStruct его значением по умолчанию. 
    
    sADC.ADC_TempSensor = ADC_TEMP_SENSOR_Enable;
    sADC.ADC_TempSensorAmplifier = ADC_TEMP_SENSOR_AMPLIFIER_Enable;
    sADC.ADC_TempSensorConversion = ADC_TEMP_SENSOR_CONVERSION_Enable;
    sADC.ADC_IntVRefConversion = ADC_VREF_CONVERSION_Disable;
    sADC.ADC_IntVRefTrimming = 1;
    ADC_Init(&sADC); //Инициализируют периферийное устройство ADC в соответствии с указанными параметрами в ADC_INITStruct. 

    /* Конфигурация ADC1 */
    ADCx_StructInit(&ADCx);
    ADCx.ADC_ClockSource = ADC_CLOCK_SOURCE_CPU;
    ADCx.ADC_SamplingMode = ADC_SAMPLING_MODE_CYCLIC_CONV;
    ADCx.ADC_ChannelSwitching = ADC_CH_SWITCHING_Disable;
    ADCx.ADC_ChannelNumber = ADC_CH_TEMP_SENSOR;
    ADCx.ADC_Channels = 0;
    ADCx.ADC_LevelControl = ADC_LEVEL_CONTROL_Disable;
    ADCx.ADC_LowLevel = 0;
    ADCx.ADC_HighLevel = 0;
    ADCx.ADC_VRefSource = ADC_VREF_SOURCE_INTERNAL;
    ADCx.ADC_IntVRefSource = ADC_INT_VREF_SOURCE_INEXACT;
    ADCx.ADC_Prescaler = ADC_CLK_div_512;
    ADCx.ADC_DelayGo = 7;
    ADC1_Init(&ADCx);

    /* Включение прерываний по окончанию преобразования и по АВОА для ADC1 */
    ADC1_ITConfig(ADC1_IT_END_OF_CONVERSION, ENABLE);

    /* Включение прерывания АЦП в контроллере NVIC */
    NVIC_EnableIRQ(ADC_IRQn);
    DEBUG_PRINTF("Ok\r\n");

    /* Включение ADC1 */
    ADC1_Cmd(ENABLE);
    while (1)
    {
    }
}
#if defined(_USE_DEBUG_UART_)
/**
 * @brief  Настройка тактовой частоты процессора.
 * @param  Нет
 * @retval Нет
 */
void ClockConfigure(void)
{
    /* Включение внешнего (HSE) тактового генератора */
    RST_CLK_HSEconfig(RST_CLK_HSE_ON);
    /* Ожидание готовности HSE */
    while (RST_CLK_HSEstatus() == ERROR)
        ;
    /* Выбор HSE в качестве источника для CPU_C1 */
    RST_CLK_CPUclkSelectionC1(RST_CLK_CPU_C1srcHSEdiv1);
    /* Выбор CPU_C1 в качестве источника для CPU_C2 */
    RST_CLK_CPU_PLLuse(DISABLE);
    /* Выбор CPU_C2 в качестве источника для CPU_C3 */
    RST_CLK_CPUclkSelection(RST_CLK_CPUclkCPU_C3);
}
#endif /* #if defined (_USE_DEBUG_UART_) */
/**
 * @brief  Сообщает имя исходного файла, номер строки и, если USE_ASSERT_INFO == 2,
 *         текст выражения, в котором произошла ошибка assert_param.
 * @param  file: указатель на имя исходного файла
 * @param  line: номер строки, где произошла ошибка assert_param
 * @param  expr: (если используется) текст выражения
 * @retval Нет
 */
#if (USE_ASSERT_INFO == 1)
void assert_failed(uint8_t *file, uint32_t line)
{
    /* Здесь пользователь может добавить собственную реализацию для вывода имени файла и номера строки.
       Например: printf("Неверное значение параметра: файл %s, строка %d\r\n", file, line) */
    /* Бесконечный цикл */
    while (1)
    {
    }
}
#elif (USE_ASSERT_INFO == 2)
void assert_failed(uint8_t *file, uint32_t line, const uint8_t *expr)
{
    /* Здесь пользователь может добавить собственную реализацию для вывода имени файла, номера строки и
       текста выражения.
       Например: printf("Неверное значение параметра (%s): файл %s, строка %d\r\n", expr, file, line) */
    /* Бесконечный цикл */
    while (1)
    {
    }
}
#endif    /* USE_ASSERT_INFO */
/** @} */ /* Конец группы ADC_ADC1_IT_MDR32F1QI */
/** @} */ /* Конец группы __MDR32F1QI_EVAL */
/** @} */ /* Конец группы __MDR32FxQI_StdPeriph_Examples */
          /******************* (C) COPYRIGHT 2024 Milandr *******************************
             Конец файла main.c */