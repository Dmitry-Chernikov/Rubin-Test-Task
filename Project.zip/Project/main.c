/* Подключение заголовочных файлов ------------------------------------------*/
#include "MDR32FxQI_config.h"
#include "MDR32FxQI_port.h"
#include "MDR32FxQI_rst_clk.h" // Управление тактовыми частотами ведется через периферийный блок RST_CLK
#include "MDR32FxQI_utils.h"
#include "MDR32FxQI_bkp.h"
#include "MDR32FxQI_adc.h" 
#include "MDR32FxQI_utils.h" 
#include <stdbool.h> 


/* Приватные определения -----------------------------------------------------*/
#define ALL_PORTS_CLK (RST_CLK_PCLK_PORTA | RST_CLK_PCLK_PORTB | \
                       RST_CLK_PCLK_PORTC | RST_CLK_PCLK_PORTD | \
                       RST_CLK_PCLK_PORTE | RST_CLK_PCLK_PORTF)

#define NUM_ADC_SAMPLING 8 // каналов АЦП
#define NUM_VOLTAGE_SAMPLING 16 // сигналов измерения напряжения
#define ADC_MAX_VALUE 4095U      // максимальное значение 12-разрядного АЦП
// значение по умолчанию – 2.4 В в зависимости от внешнего опороного напряжения с выводов ADC0_REF+ и ADC1_REF- 
#define DEFAULT_FULL_SCALE 2.4 

/* Приватные переменные ------------------------------------------------------*/
PORT_InitTypeDef PORT_InitStructure;
uint32_t LEDS_Pin[6] = {PORT_Pin_5, PORT_Pin_8, PORT_Pin_9, PORT_Pin_10, PORT_Pin_11, PORT_Pin_15};

ADCx_InitTypeDef ADCx;
int16_t ADCConvertedValue[NUM_ADC_SAMPLING];
double VoltageValues [NUM_VOLTAGE_SAMPLING];
uint32_t Counter = 0;

/* Приватные функции ---------------------------------------------------------*/
void ADC_IRQHandler(void){
    if (ADC_GetITStatus(ADC1_IT_END_OF_CONVERSION) == SET){
        uint32_t rez = ADC1_GetResult();
        if ( ((uint32_t)(rez & ADC_RESULT_CHANNEL_Msk) >> 16) == 8 ){
            ADC1_Cmd(DISABLE);
        }
        ADCConvertedValue[(uint32_t)((rez & ADC_RESULT_CHANNEL_Msk) >> 16)] = (uint32_t)(rez & ADC_RESULT_Msk);
    }
}

void Init_All_Ports(void){
    /* Включаем тактирование HSI на всех портах */
    RST_CLK_PCLKcmd(ALL_PORTS_CLK, ENABLE);

    /* Настраиваем все порты в состояние после сброса, т.е. с низким энергопотреблением */
    PORT_DeInit(MDR_PORTA);
    PORT_DeInit(MDR_PORTB);
    PORT_DeInit(MDR_PORTC);
    PORT_DeInit(MDR_PORTD);
    PORT_DeInit(MDR_PORTE);
    PORT_DeInit(MDR_PORTF);

    /* Отключаем тактирование HSI на всех портах */
    RST_CLK_PCLKcmd(ALL_PORTS_CLK, DISABLE);
}

// Возвращает максимальное напряжение из массива
int findMaxVoltage(const double arr[], int length) {
    if (length <= 0) {
        // Если массив пустой, возвращаем 0. Можно также реализовать обработку ошибки.
        return 0;
    }
    int maxVoltage = arr[0];
    for (int i = 1; i < length; i++) {
        if (arr[i] > maxVoltage) {
            maxVoltage = arr[i];
        }
    }
    return maxVoltage;
}

// Функция, выполняющая преобразование значения АЦП в вольты с указанным опорным напряжением.
double ADC_to_V_custom(uint16_t adc_value, double full_scale) {
    return ((double)adc_value * full_scale) / ADC_MAX_VALUE;
}

// Оболочка, использующая значение DEFAULT_FULL_SCALE (2.4 В) по умолчанию.
double ADC_to_V(uint16_t adc_value) {
    return ADC_to_V_custom(adc_value, DEFAULT_FULL_SCALE);
}

/**
     A
    F🄶B
    E🄳C _H
  + A-14 F-1 H-9 E-6 D-7 C-8 G-2 B-13
  - 4 12
  */
int main(void){
    uint32_t tmp_port_pin;
    uint32_t i;

    RST_CLK_DeInit();        // Установите конфигурацию часов RST_CLK в состояние сброса по умолчанию.
    SystemCoreClockUpdate(); // Обнавление SystemCoreClock в соответствии со значениями регистрации часов
    DELAY_Init(DELAY_MODE_SYSTICK);

    /* Обычно сброс выполняется перед загрузкой программы в микроконтроллер,
       и нет необходимости выполнять какие-либо специальные операции для перехода
       портов в режим низкого энергопотребления. Поэтому функция Init_All_Ports
       используется здесь исключительно в демонстрационных целях.
    */
    Init_All_Ports();

    /* Включаем RST_CLK контроллера тактовой частот, включаем тактирование HSI на портах PORTE, PORTD и ADC */
    RST_CLK_PCLKcmd(RST_CLK_PCLK_RST_CLK | RST_CLK_PCLK_PORTE | RST_CLK_PCLK_PORTD | RST_CLK_PCLK_ADC | RST_CLK_PCLK_BKP, ENABLE);

    /*Заполняет каждый член Port_initStruct его значением по умолчанию.*/
    PORT_StructInit(&PORT_InitStructure);

    /* Настраиваем контакты PORTD на цифровой выход для адресной шины индикатора АЛС324А1 (контакты 0, 1, 2, 3)
    для выдачи сигналов на адресную шину, адрес обрабатывает дешифратор адреса 
    и последовательно переключает индикторы  */
    PORT_InitStructure.PORT_Pin = (PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2 | PORT_Pin_3);
    PORT_InitStructure.PORT_OE = PORT_OE_OUT;
    PORT_InitStructure.PORT_PULL_DOWN = PORT_PULL_UP_ON;
    PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
    PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
    PORT_InitStructure.PORT_SPEED = PORT_SPEED_MAXFAST;

    /* Настраиваем контакты PORTD на цифровой выход для адресной шины коммутатора АЦП (контакты 4, 5)
    для выдачи сигналов на адресную шину, адрес обрабатывает дешифратор адреса, он переключает
    интерфейсную полату аналогового ввода */
    PORT_InitStructure.PORT_Pin = (PORT_Pin_4 | PORT_Pin_5);
    PORT_InitStructure.PORT_OE = PORT_OE_OUT;
    PORT_InitStructure.PORT_PULL_DOWN = PORT_PULL_UP_ON;
    PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
    PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
    PORT_InitStructure.PORT_SPEED = PORT_SPEED_MAXFAST;

    /* Настраиваем контакты PORTD на ADC (контакты 7, 8, 9, 10, 11, 12, 13, 14)
    для входного аналогового режима с целью измерения мВ */
    PORT_InitStructure.PORT_Pin = (PORT_Pin_7  | PORT_Pin_8  | PORT_Pin_9  |
                                   PORT_Pin_10 | PORT_Pin_11 | PORT_Pin_12 |
                                   PORT_Pin_13 | PORT_Pin_14);
    PORT_InitStructure.PORT_OE =    PORT_OE_IN;
    PORT_InitStructure.PORT_FUNC =  PORT_FUNC_PORT;
    PORT_InitStructure.PORT_MODE =  PORT_MODE_ANALOG;
    PORT_Init(MDR_PORTD, &PORT_InitStructure); // Инициализирует периферийное устройство MDR_PORTX в соответствии с указанными параметрами в Port_InitStruct. 
    
    /* Настраиваем контакты PORTE на цифровой выход для управления LED (контакты 0 - 7)
    8 сегментного ндикатора АЛС324А1*/
    PORT_InitStructure.PORT_Pin = (PORT_Pin_0  | PORT_Pin_1  | PORT_Pin_2  | PORT_Pin_3  | PORT_Pin_4  |
                                   PORT_Pin_5  | PORT_Pin_6  | PORT_Pin_7  | PORT_Pin_8  | PORT_Pin_9  |
                                   PORT_Pin_10 | PORT_Pin_11 | PORT_Pin_12 | PORT_Pin_13 | PORT_Pin_14 | PORT_Pin_15);
    PORT_InitStructure.PORT_OE = PORT_OE_OUT;
    PORT_InitStructure.PORT_PULL_DOWN = PORT_PULL_UP_ON;
    PORT_InitStructure.PORT_FUNC = PORT_FUNC_PORT;
    PORT_InitStructure.PORT_MODE = PORT_MODE_DIGITAL;
    PORT_InitStructure.PORT_SPEED = PORT_SPEED_MAXFAST;
    PORT_Init(MDR_PORTE, &PORT_InitStructure); // Инициализирует периферийное устройство MDR_PORTX в соответствии с указанными параметрами в Port_InitStruct. 


    // Инициализация тактирования для АЦП
    RST_CLK_ADCclkSelection(RST_CLK_ADCclkCPU_C1); // Выберите источник часов АЦП. 
    RST_CLK_ADCclkPrescaler(RST_CLK_ADCclkDIV2); // Конфигурирует переключатель коэффициента деления ADC_C3_SEL. 

    // Включение тактирования АЦП
    RST_CLK_ADCclkEnable(ENABLE); // Включает или отключает часы ADC_CLK. 

    /* Конфигурация ADC1 */
    ADCx_StructInit(&ADCx);
    ADCx.ADC_ClockSource = ADC_CLOCK_SOURCE_CPU;
    ADCx.ADC_SamplingMode = ADC_SAMPLING_MODE_CYCLIC_CONV;
    ADCx.ADC_ChannelSwitching = ADC_CH_SWITCHING_Enable;
    ADCx.ADC_ChannelNumber = ( ADC_CH_ADC0 | ADC_CH_ADC1 | ADC_CH_ADC2 |
                                ADC_CH_ADC3 | ADC_CH_ADC4 | ADC_CH_ADC5 |
                                ADC_CH_ADC6 | ADC_CH_ADC7 | ADC_CH_ADC6);
    ADCx.ADC_Channels = 1;
    ADCx.ADC_LevelControl = ADC_LEVEL_CONTROL_Disable;
    ADCx.ADC_LowLevel = 0;
    ADCx.ADC_HighLevel = 0;
    ADCx.ADC_VRefSource = ADC_VREF_SOURCE_EXTERNAL;
    ADCx.ADC_IntVRefSource = ADC_INT_VREF_SOURCE_INEXACT;
    ADCx.ADC_Prescaler = ADC_CLK_div_512;
    ADCx.ADC_DelayGo = 7;
    ADC1_Init(&ADCx); //Инициализируют периферийное устройство ADC в соответствии с указанными параметрами в ADC_INITStruct. 

    /* Включение прерываний по окончанию преобразования и по АВОА для ADC1 */
    ADC1_ITConfig(ADC1_IT_END_OF_CONVERSION, ENABLE);

    /* Включение прерывания АЦП в контроллере NVIC */
    NVIC_EnableIRQ(ADC_IRQn);

    while (1){
        /* Включение ADC1 */
        ADC1_Cmd(ENABLE);
        if (MDR_ADC->ADC1_CFG == DISABLE){  
            Counter = 0;
            PORT_SetBits(MDR_PORTD, PORT_Pin_4); // Включаем первую интерфейсную плату на шине число 1
            for (int i = 1; i++; i < 2){ // Опрос 2 интерфейсных плат каждая по 8 каналов, всего 16 
                for(int adcv = 0;  adcv < sizeof(ADCConvertedValue) / sizeof(ADCConvertedValue[0]); adcv++){
                    VoltageValues[Counter] = ADC_to_V(ADCConvertedValue[adcv]);
                    Counter++;
                }                
                PORT_ResetBits(MDR_PORTD, PORT_Pin_4); // Сброс 1 бита на адресной шине
                PORT_SetBits(MDR_PORTD, PORT_Pin_5); // Включаем вторую интерфейсную плату на шине число 2 
            }
            PORT_ResetBits(MDR_PORTD, PORT_Pin_4); // Сброс 1 бита на адресной шине
            PORT_ResetBits(MDR_PORTD, PORT_Pin_5); // Сброс 2 бита на адресной шине
        }

        //__disable_irq();  
        displayDouble( findMaxVoltage(VoltageValues, sizeof(VoltageValues) / sizeof(VoltageValues[0])) );
        //__enable_irq();
    }
}

// Функция для отображения числа типа double с разделением целой и дробной частей.
void displayDouble(double value){
    // Выделяем целую часть
    uint32_t intPart = (uint32_t)value;

    // Выделяем дробную часть, умножая на 1000 для получения 3 знаков после запятой.
    // Можно добавить округление, если нужно.
    uint32_t fracPart = (uint32_t)((value - intPart) * 1000);

    // Отображение целой части (1 разряда)
    // Единицы
    clearLEDs();
    pickDigit(0); // включаем область для единиц
    pickNumber(intPart % 10, SET);
    DELAY_WaitMs(5);

    // Отображение дробной части (3 знака после запятой)
    // Предполагается, что для дробной части используются следующие разряды индикаторов.
    // Если требуется отобразить разделитель (десятковую точку), это можно сделать отдельно.
    
    // Первая цифра дробной части (десятки тысячной доли, сотни после запятой)
    clearLEDs();
    pickDigit(1); // например, область для первой цифры дробной части
    pickNumber(fracPart / 100, RESET);
    DELAY_WaitMs(5);

    // Вторая цифра дробной части (десятки после запятой)
    clearLEDs();
    pickDigit(2); // область для второй цифры дробной части
    pickNumber((fracPart % 100) / 10, RESET);
    DELAY_WaitMs(5);

    // Третья цифра дробной части (единицы после запятой)
    clearLEDs();
    pickDigit(3); // область для третьей цифры дробной части
    pickNumber(fracPart % 10, RESET);
    DELAY_WaitMs(5);
}

// определение разряда
void pickDigit(int x){  
    PORT_SetBits(MDR_PORTD, PORT_Pin_0);
    PORT_SetBits(MDR_PORTD, PORT_Pin_1);
    PORT_SetBits(MDR_PORTD, PORT_Pin_2);
    PORT_SetBits(MDR_PORTD, PORT_Pin_3);
 
    switch(x){
        case 0: PORT_ResetBits(MDR_PORTE, PORT_Pin_0); break; //включаем d1
        case 1: PORT_ResetBits(MDR_PORTE, PORT_Pin_1); break; //включаем d2    
        case 2: PORT_ResetBits(MDR_PORTE, PORT_Pin_2); break; //включаем d3    
        default: PORT_ResetBits(MDR_PORTE, PORT_Pin_3); break; //включаем d4
    }
}

// определение символа (цифры)
void pickNumber(int x, bool separator){
  switch(x){
    default: zero(separator); break;
    case 1: one(separator); break;
    case 2: two(separator); break;
    case 3: three(separator); break;
    case 4: four(separator); break;
    case 5: five(separator); break;
    case 6: six(separator); break;
    case 7: seven(separator); break;
    case 8: eight(separator); break;
    case 9: nine(separator); break;
  }
} 
	
/**
     A
    F🄶B
    E🄳C _H
  + A-14 F-1 H-9 E-6 D-7 C-8 G-2 B-13
  - 4 12
  */

// очистка
void clearLEDs()
{        
    PORT_ResetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2 | PORT_Pin_3 |
                              PORT_Pin_4 | PORT_Pin_5 | PORT_Pin_6 | PORT_Pin_7);
}
 
// вывод 0
void zero(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2 | PORT_Pin_3 | PORT_Pin_4 | PORT_Pin_5);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_6 | PORT_Pin_7);
    if (separator) separator_set();
}
 
// вывод 1
void one(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_1 | PORT_Pin_2);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_3 | PORT_Pin_4 | PORT_Pin_5 | PORT_Pin_6 | PORT_Pin_7);
    if (separator) separator_set();
}
 
// вывод 2
void two(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_3 | PORT_Pin_4 | PORT_Pin_6);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_2 | PORT_Pin_5 | PORT_Pin_7);
    if (separator) separator_set();
}
	
// вывод 3
void three(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2 | PORT_Pin_3 | PORT_Pin_6);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_4 | PORT_Pin_5 | PORT_Pin_7);
    if (separator) separator_set();
}
 
// вывод 4
void four(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_1 | PORT_Pin_2 | PORT_Pin_5 | PORT_Pin_6);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_3 | PORT_Pin_4 | PORT_Pin_7);
    if (separator) separator_set();
}
 
// вывод 5
void five(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_2 | PORT_Pin_3 | PORT_Pin_5 | PORT_Pin_6);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_1 | PORT_Pin_4 | PORT_Pin_7);
    if (separator) separator_set();
}
	
// вывод 6
void six(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_2 | PORT_Pin_3 | PORT_Pin_4 | PORT_Pin_5 | PORT_Pin_6);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_1 | PORT_Pin_7);
    if (separator) separator_set();
}
 
// вывод 7
void seven(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_3 | PORT_Pin_4 | PORT_Pin_5 | PORT_Pin_6 | PORT_Pin_7);
    if (separator) separator_set();
}
 
// вывод 8
void eight(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2 | PORT_Pin_3 | PORT_Pin_4 | PORT_Pin_5 | PORT_Pin_6);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_7);
    if (separator) separator_set();
}
 
// вывод 9
void nine(bool separator){
    PORT_SetBits(MDR_PORTE, PORT_Pin_0 | PORT_Pin_1 | PORT_Pin_2 | PORT_Pin_3 | PORT_Pin_5 | PORT_Pin_6);
    PORT_ResetBits(MDR_PORTE, PORT_Pin_4 | PORT_Pin_7);
    if (separator) separator_set();
}

// Включение разделителя
void separator_set(){
    PORT_SetBits(MDR_PORTE, PORT_Pin_7);
} 

