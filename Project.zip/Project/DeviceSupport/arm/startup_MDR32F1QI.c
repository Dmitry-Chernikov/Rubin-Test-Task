/**************************************************************************//**
 * @file    startup_MDR32F1QI.c
 * @author  
 * @version V2.0
 * @date    22/07/2024
 * @brief   Стартовый файл для CMSIS‑ядра устройства MDR32F1QI на C.
 *
 *          Этот файл содержит вектор прерываний,
 *          инициализацию сегментов данных и bss, а также вызов SystemInit(),
 *          __libc_init_array() и main(). Для неиспользуемых обработчиков прерываний
 *          предусмотрена реализация по умолчанию (бесконечный цикл).
 *
 *          The present firmware is for guidance only.
 *****************************************************************************/
#include <stdint.h>
/* Объявления символов, определённых в линк‑файле */
extern uint32_t _sidata;   /* Начало данных в памяти flash (инициализационные значения) */
extern uint32_t _sdata;    /* Начало данных в RAM */
extern uint32_t _edata;    /* Конец данных в RAM */
extern uint32_t _sbss;     /* Начало сегмента bss */
extern uint32_t _ebss;     /* Конец сегмента bss */
extern uint32_t _estack;   /* Верхушка стека */
/* Объявление функций системы и libc‑инициализации */
extern void SystemInit(void);
extern void __libc_init_array(void);
extern int main(void);
/* Прототипы обработчиков исключений/прерываний */
void Reset_Handler(void);
void Default_Handler(void);
__attribute__((weak, alias("Default_Handler"))) void NMI_Handler(void);
__attribute__((weak, alias("Default_Handler"))) void HardFault_Handler(void);
/* По оригинальному ассемблерному файлу следующие 7 строк (4–10) зарезервированы,
   поэтому их обработчики не определяются */
__attribute__((weak, alias("Default_Handler"))) void SVC_Handler(void);
__attribute__((weak, alias("Default_Handler"))) void PendSV_Handler(void);
__attribute__((weak, alias("Default_Handler"))) void SysTick_Handler(void);
/* Внешние прерывания */
__attribute__((weak, alias("Default_Handler"))) void MIL_STD_1553B2_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void MIL_STD_1553B1_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void USB_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void CAN1_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void CAN2_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void DMA_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void UART1_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void UART2_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void SSP1_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void BUSY_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void ARINC429R_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void POWER_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void WWDG_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void TIMER4_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void TIMER1_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void TIMER2_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void TIMER3_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void ADC_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void ETHERNET_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void SSP3_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void SSP2_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void ARINC429T1_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void ARINC429T2_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void ARINC429T3_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void ARINC429T4_IRQHandler(void);
/* Зарезервировано: позиция 41 и 42 */
__attribute__((weak, alias("Default_Handler"))) void BKP_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void EXT_INT1_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void EXT_INT2_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void EXT_INT3_IRQHandler(void);
__attribute__((weak, alias("Default_Handler"))) void EXT_INT4_IRQHandler(void);
/**************************************************************************//**
 * @brief   Функция по умолчанию для необработанных прерываний.
 *****************************************************************************/
void Default_Handler(void)
{
    while (1)
    {
        /* Бесконечный цикл */
    }
}
/**************************************************************************//**
 * @brief   Обработчик сброса.
 *
 *          Инициализирует сегмент данных, очищает bss, вызывает SystemInit,
 *          __libc_init_array и main. В случае возврата из main выполнение зациклится.
 *****************************************************************************/
void Reset_Handler(void)
{
    uint32_t *pSrc, *pDest;
    /* Копирование инициализационных данных из флеш в сегмент данных RAM */
    pSrc = &_sidata;
    for (pDest = &_sdata; pDest < &_edata; )
    {
        *pDest++ = *pSrc++;
    }
    /* Обнуление сегмента bss */
    for (pDest = &_sbss; pDest < &_ebss; )
    {
        *pDest++ = 0;
    }
    /* Инициализация системы */
    SystemInit();
    /* Инициализация статических конструкторов C++/библиотеки */
    __libc_init_array();
    /* Вход в основную программу */
    main();
    /* Если main возвратился, остаёмся в бесконечном цикле */
    while (1)
    {
    }
}
/**************************************************************************//**
 * @brief   Таблица векторов прерываний.
 *
 *          Размещена в секции ".isr_vector" и используется при сбросе.
 *****************************************************************************/
__attribute__((section(".isr_vector"), used))
const void (*VectorTable[])(void) = {
    (void (*)(void))(&_estack),         /* Начальное значение SP */
    Reset_Handler,                      /* Reset Handler */
    NMI_Handler,                        /* NMI Handler */
    HardFault_Handler,                  /* Hard Fault Handler */
    0,                                  /* Reserved */
    0,                                  /* Reserved */
    0,                                  /* Reserved */
    0,                                  /* Reserved */
    0,                                  /* Reserved */
    0,                                  /* Reserved */
    0,                                  /* Reserved */
    SVC_Handler,                        /* SVCall Handler */
    0,                                  /* Reserved */
    0,                                  /* Reserved */
    PendSV_Handler,                     /* PendSV Handler */
    SysTick_Handler,                    /* SysTick Handler */
    
    /* Внешние прерывания */
    MIL_STD_1553B2_IRQHandler,          /*  0: MIL_STD_1553B2 Handler */
    MIL_STD_1553B1_IRQHandler,          /*  1: MIL_STD_1553B1 Handler */
    USB_IRQHandler,                     /*  2: USB Host Handler */
    CAN1_IRQHandler,                    /*  3: CAN1 Handler */
    CAN2_IRQHandler,                    /*  4: CAN2 Handler */
    DMA_IRQHandler,                     /*  5: DMA Handler */
    UART1_IRQHandler,                   /*  6: UART1 Handler */
    UART2_IRQHandler,                   /*  7: UART2 Handler */
    SSP1_IRQHandler,                    /*  8: SSP1 Handler */
    BUSY_IRQHandler,                    /*  9: BUSY / NAND Flash Handler */
    ARINC429R_IRQHandler,               /* 10: ARINC429R Handler */
    POWER_IRQHandler,                   /* 11: POWER Handler */
    WWDG_IRQHandler,                    /* 12: WWDG Handler */
    TIMER4_IRQHandler,                  /* 13: TIMER4 Handler */
    TIMER1_IRQHandler,                  /* 14: TIMER1 Handler */
    TIMER2_IRQHandler,                  /* 15: TIMER2 Handler */
    TIMER3_IRQHandler,                  /* 16: TIMER3 Handler */
    ADC_IRQHandler,                     /* 17: ADC Handler */
    ETHERNET_IRQHandler,                /* 18: Ethernet Handler */
    SSP3_IRQHandler,                    /* 19: SSP3 Handler */
    SSP2_IRQHandler,                    /* 20: SSP2 Handler */
    ARINC429T1_IRQHandler,              /* 21: ARINC429T1 Handler */
    ARINC429T2_IRQHandler,              /* 22: ARINC429T2 Handler */
    ARINC429T3_IRQHandler,              /* 23: ARINC429T3 Handler */
    ARINC429T4_IRQHandler,              /* 24: ARINC429T4 Handler */
    0,                                  /* 25: Reserved */
    0,                                  /* 26: Reserved */
    BKP_IRQHandler,                     /* 27: BKP Handler */
    EXT_INT1_IRQHandler,                /* 28: EXT_INT1 Handler */
    EXT_INT2_IRQHandler,                /* 29: EXT_INT2 Handler */
    EXT_INT3_IRQHandler,                /* 30: EXT_INT3 Handler */
    EXT_INT4_IRQHandler                 /* 31: EXT_INT4 Handler */
};